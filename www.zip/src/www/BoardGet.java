package www;

public class BoardGet {

}
